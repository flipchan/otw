Off the wire crypto
=======================

one encryption library to rule them all.

An easy to use encryption library mainly ment for LayerProx(github.com/flipchan/LayerProx)
aims to be easy to use and provide strong crypto it comes with multiple functions

the justencrypt() function encrypts the data with pgp -> aes-ctr 256 and adds
a hmac
 

----

